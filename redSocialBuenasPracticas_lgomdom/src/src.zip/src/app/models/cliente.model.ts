export interface Cliente {
  nombre: string;
  apellido: string;
  email: string;
  nacionalidad: string;
}
