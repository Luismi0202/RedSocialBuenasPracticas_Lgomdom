import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, NgForm } from '@angular/forms';
import { Router } from '@angular/router';
import {
  IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonLabel, IonInput,
  IonButton, IonList, IonNote
} from '@ionic/angular/standalone';
import { DataService } from '../services/data.service';
import { Cliente } from '../models/cliente.model';

@Component({
  standalone: true,
  selector: 'app-cliente',
  imports: [
    CommonModule, FormsModule,
    IonHeader, IonToolbar, IonTitle, IonContent,
    IonItem, IonLabel, IonInput, IonButton, IonList, IonNote
  ],
  templateUrl: './cliente.page.html',
  styleUrls: ['./cliente.page.scss']
})
export class ClientePage {
  private dataService = inject(DataService);
  private router = inject(Router);

  // Estado visual del botón
  feedbackActive = false;

  model: Cliente = {
    nombre: '',
    apellido: '',
    email: '',
    nacionalidad: ''
  };

  guardar(f: NgForm) {
    if (!f.valid) return;

    // Guardar datos en el servicio
    this.dataService.setClienteData(this.model);

    // Feedback visual temporal del botón
    this.feedbackActive = true;
    setTimeout(() => {
      this.feedbackActive = false;
      // Navegar a la página de datos del cliente
      this.router.navigate(['/list/datos-cliente']);
    }, 1000);
  }
}
