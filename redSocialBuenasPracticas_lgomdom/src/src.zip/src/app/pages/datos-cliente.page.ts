import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonLabel, IonList } from '@ionic/angular/standalone';
import { DataService } from '../services/data.service';
import { Cliente } from '../models/cliente.model';

@Component({
  standalone: true,
  selector: 'app-datos-cliente',
  imports: [CommonModule, IonHeader, IonToolbar, IonTitle, IonContent, IonItem, IonLabel, IonList],
  templateUrl: './datos-cliente.page.html',
  styleUrls: ['./datos-cliente.page.scss']
})
export class DatosClientePage {
  private dataService = inject(DataService);

  cliente: Cliente | null = this.dataService.getClienteData();
}
