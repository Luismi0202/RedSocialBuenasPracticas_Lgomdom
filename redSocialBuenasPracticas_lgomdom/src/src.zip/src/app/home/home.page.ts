import { Component, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { RouterLink, RouterOutlet } from '@angular/router';
import {
  IonHeader, IonToolbar, IonTitle, IonButtons, IonButton,
  IonContent, IonItem, IonLabel, IonInput, IonRouterOutlet, IonFooter
} from '@ionic/angular/standalone';
import { UserStateService } from '../core/user-state.service';
import { CounterComponent } from '../components/counter/counter.component';
import { CalculadoraComponent, ResultadoCalculadora } from '../components/calculadora/calculadora.component';

@Component({
  standalone: true,
  selector: 'app-home',
  imports: [
    CommonModule, FormsModule, RouterLink, RouterOutlet,
    IonHeader, IonToolbar, IonTitle, IonButtons, IonButton,
    IonContent, IonItem, IonLabel, IonInput, IonRouterOutlet,
    CounterComponent, IonFooter, CalculadoraComponent
  ],
  templateUrl: './home.page.html'
})
export class HomePage {
  // Valores para la calculadora
  valorA: number = 0;
  valorB: number = 0;

  // Resultados de la calculadora
  resultadosCalc: ResultadoCalculadora | null = null;

  // Contador gestionado en el padre y mostrado en el hijo
  parentCount = 0;

  // Mensaje cuando el hijo alcanza una decena
  milestoneMsg = '';

  // Variable temporal para forzar el cálculo
  private calculadoraRef: any;

  calcular() {
    // Simular el cálculo directamente aquí o podríamos usar ViewChild
    // Para este caso, calcularemos directamente en el padre
    const suma = Number(this.valorA) + Number(this.valorB);
    const resta = Number(this.valorA) - Number(this.valorB);
    const multiplicacion = Number(this.valorA) * Number(this.valorB);
    
    let division: number | null = null;
    let error: string | undefined = undefined;

    if (Number(this.valorB) === 0) {
      error = 'División por cero no permitida';
    } else {
      division = Number(this.valorA) / Number(this.valorB);
    }

    this.resultadosCalc = {
      suma,
      resta,
      multiplicacion,
      division,
      error
    };
  }

  onResultadoCalculadora(res: ResultadoCalculadora) {
    this.resultadosCalc = res;
  }

  incrementFromParent() {
    this.parentCount++;
  }

  onMilestoneReached(n: number) {
    this.milestoneMsg = `Ha llegado al ${n}`;
    setTimeout(() => this.milestoneMsg = '', 3000);
  }
}
