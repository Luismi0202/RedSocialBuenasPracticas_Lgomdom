import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';

export interface ResultadoCalculadora {
  suma: number;
  resta: number;
  multiplicacion: number;
  division: number | null;
  error?: string;
}

@Component({
  standalone: true,
  selector: 'app-calculadora',
  imports: [CommonModule],
  templateUrl: './calculadora.component.html',
  styleUrls: ['./calculadora.component.scss']
})
export class CalculadoraComponent {
  @Input() a: number = 0;
  @Input() b: number = 0;

  @Output() resultado = new EventEmitter<ResultadoCalculadora>();

  calcular() {
    const suma = Number(this.a) + Number(this.b);
    const resta = Number(this.a) - Number(this.b);
    const multiplicacion = Number(this.a) * Number(this.b);
    
    let division: number | null = null;
    let error: string | undefined = undefined;

    if (Number(this.b) === 0) {
      error = 'División por cero no permitida';
    } else {
      division = Number(this.a) / Number(this.b);
    }

    const resultados: ResultadoCalculadora = {
      suma,
      resta,
      multiplicacion,
      division,
      error
    };

    this.resultado.emit(resultados);
  }
}